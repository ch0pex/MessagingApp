Para la correcta ejecución del código correspondiente al cliente será necesario haber seguido los pasos de setup necesarios detallados en el enunciado de la práctica. Para facilitar la instalación de los paquetes necesarios para la correcta ejecución del cliente en python, hemos proporcionado un fichero llamado requirements.txt, el cual se ejecuta mediante el siguiente comando: 

pip install -r requirements.txt

Una vez instalados los paquetes y también python3-tk con el comando sudo apt-get install python3-tk, podremos ejecutar el cliente mediante el siguiente comando: 

python3 client.py -s localhost -p 8888

Puesto que el servidor está escrito en el lenguaje por compilación C, es necesario compilar el código para poder ejecutarlo. Para ello hemos creado el correspondiente makefile que convierte el código fuente en el correspondiente ejecutable server. Para compilar el codigo con dicho makefile es tan sencillo como estar en la carpeta que lo contiene y escribir el comando make. Para la ejecución del servidor, se ajusta a lo especificado en el enunciado, con el siguiente comando: 

./server -p 8888

Para ejecutar el servicio web basta con tener instalado los modulos de python del requirements.txt como se ha descrito anteriormente. El comando para ejecutar dicho servicio web es el siguiente: 

python3 web_service.py
